export const barotraumaVsDcsLecture = {
    id: 'barotrauma-vs-dcs',
    title: 'Barotrauma vs DCS',
    description: 'Pełne porównanie urazów ciśnieniowych i choroby dekompresyjnej wraz z pierwszą pomocą.',
    content: `<h2>Barotrauma vs. Choroba Dekompresyjna (DCS) – Pełne Porównanie</h2>
        
        <h3>Wstęp: Dwa Rodzaje Zaburzeń Ciśnieniowych (DCI)</h3>
        <p>Urazy związane ze zmianą ciśnienia podczas nurkowania (tzw. Zespół Zaburzeń Ciśnieniowych – DCI) dzielimy na dwie główne kategorie: <strong>Barotrauma (urazy ciśnieniowe)</strong> i <strong>Choroba Dekompresyjna (DCS)</strong>. Obydwa stany wymagają natychmiastowej opieki medycznej i często leczenia rekompresją w komorze dekompresyjnej. Na potrzeby pierwszej pomocy przedmedycznej, oba te urazy można traktować jako jedną grupę – DCI.</p>

        <hr>

        <h3>I. Urazy Ciśnieniowe (Barotrauma)</h3>
        <p>Barotrauma to uraz mechaniczny spowodowany nadmierną różnicą ciśnień między otoczeniem a gazem uwięzionym w przestrzeniach powietrznych ciała. Powstają one, gdy gaz w zamkniętych przestrzeniach kurczy się (podczas zanurzania, tzw. squeeze) lub rozszerza (podczas wynurzania).</p>

        <h4>Prawa Fizyczne: Prawo Boyle'a-Mariotte'a</h4>
        <p>Barotrauma jest rządzona przez <strong>Prawo Boyle'a-Mariotte'a</strong>, które mówi, że objętość gazu jest odwrotnie proporcjonalna do ciśnienia, któremu jest poddawana. Największe zmiany objętości gazów na każdy metr głębokości występują na głębokościach 1–10 metrów, co jest najbardziej niebezpieczną strefą zmiany ciśnienia.</p>

        <h4>A. Barotrauma podczas Wynurzania (UCP - Urazy Ciśnieniowe Płuc)</h4>
        <p>Są to <strong>najpoważniejsze urazy nurkowe</strong>. Występują, gdy rozszerzający się gaz jest uwięziony w płucach, co prowadzi do rozerwania pęcherzyków płucnych, gdy nadciśnienie przekroczy 0,12 bara (50 do 90 mm Hg wyższe od ciśnienia otoczenia).</p>

        <table style="width:100%; border-collapse: collapse; margin: 20px 0;">
            <thead>
                <tr style="background-color: rgba(0,209,178,0.2);">
                    <th style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Typ Urazu</th>
                    <th style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Kluczowa Przyczyna</th>
                    <th style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Objawy</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);"><strong>Tętniczy Zator Gazowy (AGE)</strong></td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Wstrzymanie oddechu podczas wynurzania</td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Utrata przytomności (natychmiast lub do 4-6 min), śpiączka, drgawki, paraliż, ból głowy, zaburzenia mowy/wzroku/równowagi, zatrzymanie krążenia i oddychania</td>
                </tr>
                <tr>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);"><strong>Odma Śródpiersia</strong></td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Wstrzymanie oddechu podczas wynurzania</td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Ból za mostkiem, zaburzenia oddychania, osłabienie, zmiana głosu</td>
                </tr>
                <tr>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);"><strong>Odma Podskórna</strong></td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Wstrzymanie oddechu podczas wynurzania</td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Opuchlizna szyi/obojczyków, trzaski przy ucisku skóry</td>
                </tr>
                <tr>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);"><strong>Odma Opłucnowa</strong></td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Wstrzymanie oddechu podczas wynurzania</td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Ostry ból w klatce piersiowej, płytki/szybki oddech, duszność, zasinienie skóry/ust/paznokci</td>
                </tr>
            </tbody>
        </table>

        <h4>B. Inne Barotraumy</h4>
        <table style="width:100%; border-collapse: collapse; margin: 20px 0;">
            <thead>
                <tr style="background-color: rgba(0,209,178,0.2);">
                    <th style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Typ Urazu</th>
                    <th style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Przyczyna</th>
                    <th style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Objawy</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);"><strong>Barotrauma Ucha (Aerotitis)</strong></td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Brak wyrównania ciśnienia podczas zanurzania</td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Narastający ucisk → ból. Przy pęknięciu błony: nagłe ustąpienie bólu, zimno w uchu, zawroty głowy, nudności, wymioty, utrata orientacji</td>
                </tr>
                <tr>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);"><strong>Barotrauma Zatoki</strong></td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Niedrożność ujścia zatok (katar, infekcja, polipy)</td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Silny ból w okolicy zatoki lub górnych zębów, krwawienie z nosa</td>
                </tr>
                <tr>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);"><strong>Barotrauma Zęba</strong></td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Powietrze pod plombą/koroną</td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Silny ból zęba, możliwe pęknięcie zęba podczas wynurzania</td>
                </tr>
            </tbody>
        </table>

        <div class="result-warning-box">
            ⚠️ <strong>KLUCZOWA ZASADA (Barotrauma):</strong> <u>CIĄGŁE ODDYCHANIE!</u> NIGDY NIE WSTRZYMUJ ODDECHU podczas wynurzania!
        </div>

        <h4>Profilaktyka Barotraumy:</h4>
        <ul>
            <li><strong>Oddychanie:</strong> Utrzymuj ciągły, rytmiczny oddech przez całe nurkowanie</li>
            <li><strong>Wyrównywanie:</strong> Wyrównuj ciśnienie w uszach i masce podczas zanurzania (często i delikatnie)</li>
            <li><strong>Zdrowie:</strong> Nie nurkuj z katarem lub po chorobach układu oddechowego (przerwa min. 1 miesiąc)</li>
            <li><strong>Prędkość:</strong> Stosuj prawidłową prędkość wynurzania (max 9-10 m/min)</li>
        </ul>

        <h4>Pierwsza Pomoc (Barotrauma Płuc / AGE):</h4>
        <ol>
            <li><strong>Wezwij pomoc:</strong> Natychmiast wezwij służby ratunkowe (112/999)</li>
            <li><strong>Tlen 100%:</strong> Podaj maksymalny przepływ tlenu (jeśli masz kwalifikacje). <em>Tlen jest najważniejszym lekarstwem!</em></li>
            <li><strong>Pozycja:</strong> Ułóż poszkodowanego poziomo (może woleć pozycję siedzącą przy duszności)</li>
            <li><strong>Rekompresja:</strong> Najważniejsza jest natychmiastowa rekompresja w komorze hiperbarycznej</li>
            <li><strong>NIGDY:</strong> Nie zabieraj nurka z powrotem pod wodę!</li>
        </ol>

        <hr>

        <h3>II. Choroba Dekompresyjna (DCS)</h3>
        <p>Choroba dekompresyjna (DCS lub choroba kesonowa) to zespół objawów spowodowanych uwolnieniem nadmiaru gazu obojętnego (np. azotu) w tkankach na skutek nieprawidłowego wynurzania.</p>

        <h4>Prawa Fizyczne: Prawo Henry'ego</h4>
        <p>DCS jest związana z <strong>Prawem Henry'ego</strong>, które mówi, że objętość gazu rozpuszczonego w cieczy (tkankach) rośnie wraz ze wzrostem ciśnienia.</p>

        <p><strong>Mechanizm:</strong> Podczas wynurzania ciśnienie otoczenia spada zbyt szybko, a nadmiar rozpuszczonego azotu wydziela się z roztworu i formuje pęcherzyki w tkankach i krwioobiegu. DCS występuje, gdy wchłonięte gazy obojętne tworzą pęcherzyki z powodu wysokiego gradientu desaturacji.</p>

        <h4>Objawy i Typy DCS</h4>
        <p>Objawy DCS zwykle pojawiają się między <strong>15 minutą a 12 godziną po wynurzeniu</strong>, przy czym 98% objawów występuje w ciągu pierwszych 24 godzin.</p>

        <table style="width:100%; border-collapse: collapse; margin: 20px 0;">
            <thead>
                <tr style="background-color: rgba(255,56,96,0.2);">
                    <th style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Typ DCS</th>
                    <th style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Kluczowe Objawy</th>
                    <th style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Mechanizm</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);"><strong>Typ I (Postać Lekka)</strong></td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">
                        • Bóle stawowo-mięśniowe (głęboki, uporczywy ból w okolicach dużych stawów)<br>
                        • Swędzenie skóry, marmurkowatość (plamy białe, sine, czerwone)<br>
                        • Zmęczenie jak przy grypie
                    </td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Pęcherzyki azotu pozanaczyniowo w tkankach obwodowych</td>
                </tr>
                <tr>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);"><strong>Typ II (Postać Ciężka)</strong></td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">
                        <strong>Objawy neurologiczne:</strong> Utrata przytomności, ból głowy, drgawki, paraliż, mrowienie/drętwienie, zaburzenia mowy/wzroku/równowagi<br>
                        <strong>Objawy płucno-krążeniowe:</strong> Duszność, spłycony oddech, suchy kaszel, ból w klatce piersiowej, objawy zawału
                    </td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Pęcherzyki azotu w naczyniach krwionośnych. Może zablokować filtr płucny lub spowodować tętniczy zator gazowy</td>
                </tr>
            </tbody>
        </table>

        <p><strong>Uwaga:</strong> Niemożliwym jest odróżnienie neurologicznej postaci DCS od AGE bez znajomości przebiegu nurkowania. Nie należy sztywno dzielić DCS na typ I i II, ponieważ u nurka mogą występować objawy charakterystyczne dla obu typów.</p>

        <h4>Czynniki Ryzyka Zwiększające Podatność na DCS:</h4>
        <ul>
            <li>Wiek (zwykle powyżej 40/50 lat)</li>
            <li>Niska sprawność fizyczna i otyłość</li>
            <li>Zmęczenie lub brak snu</li>
            <li>Odwodnienie</li>
            <li>Narażenie na zimną wodę i wychłodzenie</li>
            <li>Intensywny wysiłek fizyczny w trakcie lub po nurkowaniu</li>
            <li>Spożywanie alkoholu i/lub narkotyków</li>
            <li>Lot samolotem lub podróż na wysokość 300m+ po nurkowaniu</li>
            <li>Nurkowania wielokrotne w ciągu dnia lub wielodniowe</li>
            <li>Nurkowanie głębokie i o długim czasie trwania</li>
            <li>Wady serca (np. przetrwały otwór owalny - PFO)</li>
        </ul>

        <div class="result-warning-box">
            ⚠️ <strong>KLUCZOWA ZASADA (DCS):</strong> Zawsze <u>nurkuj w granicach limitów Dopplera</u> (limitów bezdekompresyjnych). Bądź konserwatywny (ostrożny) podczas serii nurkowań!
        </div>

        <h4>Profilaktyka DCS:</h4>
        <ul>
            <li><strong>Prędkość wynurzania:</strong> Nie większa niż 9-10 m/min</li>
            <li><strong>Przystanek bezpieczeństwa:</strong> Wykonaj 3-5 minut na 3-5 metrach po KAŻDYM nurkowaniu (ok. 40% wypadków DCS to nurkowania bez przystanku!)</li>
            <li><strong>Limity:</strong> Nurkuj w granicach limitów bezdekompresyjnych</li>
            <li><strong>Nawodnienie:</strong> Dbaj o odpowiednie nawodnienie organizmu</li>
            <li><strong>Wysiłek:</strong> Unikaj intensywnego wysiłku fizycznego po nurkowaniu</li>
            <li><strong>Lot:</strong> Odczekaj min. 24h przed lotem samolotem</li>
        </ul>

        <h4>Pierwsza Pomoc (DCS):</h4>
        <ol>
            <li><strong>Wezwij pomoc:</strong> Natychmiast (112/999). Poinformuj o konieczności transportu do komory dekompresyjnej. Polska: Krajowy Ośrodek Medycyny Hiperbarycznej (58 622 51 63)</li>
            <li><strong>Tlen 100%:</strong> Bezzwłocznie podaj maksymalny przepływ tlenu (jeśli masz kwalifikacje)</li>
            <li><strong>Pozycja:</strong> Ułóż poszkodowanego poziomo</li>
            <li><strong>Płyny:</strong> Podaj do 1 litra niegazowanych płynów (jeśli przytomny i bez duszności)</li>
            <li><strong>Rekompresja:</strong> Leczenie w komorze dekompresyjnej – opóźnienie jest najgorszą rzeczą!</li>
        </ol>

        <hr>

        <h3>Podsumowanie Kluczowych Różnic</h3>
        <table style="width:100%; border-collapse: collapse; margin: 20px 0;">
            <thead>
                <tr style="background-color: rgba(0,209,178,0.3);">
                    <th style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Kwestia</th>
                    <th style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Barotrauma (UCP)</th>
                    <th style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Choroba Dekompresyjna (DCS)</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);"><strong>Główne Prawo Fizyki</strong></td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Prawo Boyle'a (zależność V/P)</td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Prawo Henry'ego (rozpuszczalność gazu)</td>
                </tr>
                <tr>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);"><strong>Główna Przyczyna</strong></td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Wstrzymanie oddechu podczas wynurzania</td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Zbyt szybkie wynurzanie / zbyt długi czas na głębokości</td>
                </tr>
                <tr>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);"><strong>Mechanizm Urazu</strong></td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Mechaniczne rozerwanie tkanek przez rozprężający się gaz</td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Tworzenie pęcherzyków gazu obojętnego w tkankach i krwi</td>
                </tr>
                <tr>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);"><strong>Kiedy Objawy?</strong></td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Natychmiast lub do 30 minut po wynurzeniu</td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Zazwyczaj 15 min do 12 godz. po nurkowaniu</td>
                </tr>
                <tr>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);"><strong>Kluczowa Profilaktyka</strong></td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">CIĄGŁE ODDYCHANIE podczas wynurzenia</td>
                    <td style="padding: 10px; border: 1px solid rgba(255,255,255,0.2);">Nurkowanie w granicach limitów + wolne wynurzanie + przystanek bezpieczeństwa</td>
                </tr>
            </tbody>
        </table>

        <div class="result-warning-box">
            🚨 <strong>PAMIĘTAJ:</strong> W obu przypadkach najważniejsze to:<br>
            1. Natychmiastowe wezwanie pomocy medycznej<br>
            2. Podanie 100% tlenu<br>
            3. Rekompresja w komorze dekompresyjnej<br>
            4. <em>Nie próbuj rekompresji w wodzie!</em>
        </div>`,
    quiz: [
        {
            question: "Jaka jest kluczowa różnica w przyczynie między Barotraumą Płuc a DCS?",
            options: [
                "Barotrauma wynika z wychłodzenia, a DCS z przegrzania",
                "Barotrauma to efekt wstrzymania oddechu (mechaniczny), a DCS to efekt nasycenia azotem (rozpuszczalność)",
                "Barotrauma dotyczy tylko uszu, a DCS tylko płuc",
                "Nie ma żadnej różnicy"
            ],
            correctAnswer: 1,
            explanation: "Barotrauma płuc to mechaniczne uszkodzenie przez rozszerzający się gaz (Boyle). DCS to wydzielanie się pęcherzyków gazu z tkanek (Henry)."
        },
        {
            question: "Które z poniższych jest objawem neurologicznym (ciężkim) DCS/AGE?",
            options: [
                "Lekki ból ucha",
                "Swędzenie skóry",
                "Utrata przytomności, paraliż, zaburzenia mowy",
                "Zmęczenie po nurkowaniu"
            ],
            correctAnswer: 2,
            explanation: "Objawy neurologiczne świadczą o zajęciu ośrodkowego układu nerwowego (mózg, rdzeń) i są stanem bezpośredniego zagrożenia życia."
        },
        {
            question: "Co jest najważniejszym 'lekarstwem' w pierwszej pomocy przy wypadkach nurkowych?",
            options: [
                "Ciepła herbata",
                "Aspiryna",
                "100% Tlen",
                "Zimny okład"
            ],
            correctAnswer: 2,
            explanation: "Tlen 100% przyspiesza eliminację azotu, zmniejsza obrzęki i niedotlenienie tkanek. Należy go podać jak najszybciej."
        },
        {
            question: "Kiedy najczęściej pojawiają się objawy Tętniczego Zatoru Gazowego (AGE) po nurkowaniu?",
            options: [
                "W ciągu 1-2 godzin",
                "Natychmiast lub w ciągu kilku minut (do 30 min)",
                "Po 24 godzinach",
                "Tylko pod wodą"
            ],
            correctAnswer: 1,
            explanation: "AGE (związany z Barotraumą płuc) pojawia się zazwyczaj natychmiast lub w ciągu kilku minut po wynurzeniu, w przeciwieństwie do DCS (15 min - 12h)."
        },
        {
            question: "Która procedura jest ZABRONIONA w pierwszej pomocy przy wypadkach nurkowych?",
            options: [
                "Podanie 100% tlenu",
                "Rekompresja w wodzie (zabieranie poszkodowanego z powrotem pod wodę)",
                "Wezwanie pomocy medycznej",
                "Ułożenie poszkodowanego poziomo"
            ],
            correctAnswer: 1,
            explanation: "NIGDY nie zabieraj poszkodowanego z powrotem pod wodę! To może pogorszyć stan i narazić na kolejne zagrożenia. Tylko rekompresja w komorze jest bezpieczna."
        },
        {
            question: "Jaki jest najważniejszy środek zapobiegawczy dla Barotraumy Płuc?",
            options: [
                "Nurkowanie z Nitroksem",
                "Wolne wynurzanie",
                "CIĄGŁE ODDYCHANIE - nigdy nie wstrzymuj oddechu podczas wynurzania",
                "Przystanek bezpieczeństwa na 5m"
            ],
            correctAnswer: 2,
            explanation: "Kluczowa zasada: NIGDY nie wstrzymuj oddechu podczas wynurzania! To najważniejszy środek zapobiegający UCP/AGE."
        },
        {
            question: "Który objaw sugeruje DCS Typ II (ciężki) zamiast Typ I?",
            options: [
                "Bóle stawów i mięśni",
                "Swędzenie skóry",
                "Paraliż, zaburzenia mowy, utrata przytomności",
                "Zmęczenie"
            ],
            correctAnswer: 2,
            explanation: "Objawy neurologiczne (paraliż, zaburzenia mowy/wzroku, utrata przytomności) wskazują na DCS Typ II - stan bezpośredniego zagrożenia życia."
        },
        {
            question: "Dlaczego przystanek bezpieczeństwa (3-5 min na 5m) jest tak ważny w zapobieganiu DCS?",
            options: [
                "Pozwala oszczędzać powietrze",
                "Daje czas na bezpieczne odgazowanie nadmiaru azotu",
                "Jest wymagany prawnie",
                "Pomaga wyrównać ciśnienie w uszach"
            ],
            correctAnswer: 1,
            explanation: "Przystanek bezpieczeństwa znacząco redukuje ryzyko DCS, umożliwiając bezpieczne uwolnienie azotu. Ok. 40% wypadków DCS to nurkowania bez przystanku!"
        },
        {
            question: "Ile czasu należy odczekać przed lotem samolotem po nurkowaniu?",
            options: [
                "1 godzina",
                "6 godzin",
                "Co najmniej 18-24 godziny",
                "Można lecieć od razu"
            ],
            correctAnswer: 2,
            explanation: "Minimum 18-24h przed lotem! Obniżone ciśnienie na wysokości zwiększa ryzyko DCS przez uwolnienie rozpuszczonego azotu."
        },
        {
            question: "Co wspólnego mają Barotrauma i DCS w leczeniu?",
            options: [
                "Oba leczy się antybiotykami",
                "Oba wymagają 100% tlenu i rekompresji w komorze dekompresyjnej",
                "Oba leczy się aspiryną",
                "Nie wymagają leczenia"
            ],
            correctAnswer: 1,
            explanation: "Mimo różnych mechanizmów, oba wymagają natychmiastowego podania 100% tlenu i leczenia w komorze dekompresyjnej. Czas jest kluczowy!"
        },
        {
            question: "Mechanizm bólu: Jaka jest różnica między bólem w Barotraumie a DCS?",
            options: [
                "Nie ma różnicy",
                "Barotrauma: ból ostry, miejscowy, narastający przy zmianie ciśnienia. DCS: ból tępy, głęboki, stały.",
                "Barotrauma nie boli, DCS boli bardzo",
                "Barotrauma to swędzenie, DCS to ból"
            ],
            correctAnswer: 1,
            explanation: "Barotrauma to uraz mechaniczny (np. naciągnięcie błony), co daje ostry ból skorelowany z ciśnieniem. Ból w DCS ('bends') jest często trudny do zlokalizowania, tępy i głęboki."
        },
        {
            question: "Który uraz jest bardziej prawdopodobny, jeśli objawy wystąpiły 2 minuty po wynurzeniu?",
            options: [
                "DCS (Choroba Dekompresyjna)",
                "AGE (Zator Gazowy / Barotrauma Płuc)",
                "Narkoza azotowa",
                "Hipotermia"
            ],
            correctAnswer: 1,
            explanation: "Objawy natychmiastowe (0-10 min) po wynurzeniu niemal zawsze sugerują zator gazowy (AGE) lub barotraumę płuc. DCS zazwyczaj rozwija się wolniej (powyżej 15-20 min)."
        },
        {
            question: "Które prawo gazowe odpowiada za Barotraumę, a które za DCS?",
            options: [
                "Oba Prawo Archimedesa",
                "Barotrauma: Boyle (objętość). DCS: Henry (rozpuszczalność).",
                "Barotrauma: Henry. DCS: Boyle.",
                "Barotrauma: Dalton. DCS: Charles."
            ],
            correctAnswer: 1,
            explanation: "Boyle wyjaśnia mechaniczne zmiany objętości (rozrywanie tkanek). Henry wyjaśnia nasycanie tkanek gazem (bąbelki w krwi)."
        },
        {
            question: "Co to są 'Silent Bubbles' (Ciche Pęcherzyki)?",
            options: [
                "Pęcherzyki, które nie pękają",
                "Mikropęcherzyki w żyle, które nie dają objawów DCS, ale są obecne po wielu nurkowaniach",
                "Pęcherzyki w napoju",
                "Pęcherzyki w masce"
            ],
            correctAnswer: 1,
            explanation: "Ciche pęcherzyki występują po wielu nurkowaniach bezobjawowo. Są filtrowane przez płuca, ale ich nadmiar może prowadzić do DCS."
        },
        {
            question: "Jakie nawodnienie jest zalecane w pierwszej pomocy przy DCS?",
            options: [
                "Kawa lub herbata",
                "Alkohol",
                "Woda niegazowana, jeśli poszkodowany jest przytomny",
                "Nic nie podawać"
            ],
            correctAnswer: 2,
            explanation: "Nawodnienie (ok. 1 litr w ciągu godziny) pomaga rozrzedzić krew i poprawić mikrokrążenie, co ułatwia eliminację azotu."
        },
        {
            question: "W którym przypadku transport do komory jest pilniejszy?",
            options: [
                "W obu jest krytycznie ważny",
                "Tylko przy DCS skórnym",
                "Tylko przy bólu ucha",
                "Można poczekać do jutra"
            ],
            correctAnswer: 0,
            explanation: "Zarówno AGE (zator) jak i ciężki DCS są stanami zagrożenia życia/zdrowia. W obu przypadkach czas dotarcia do komory decyduje o rokowaniach."
        },
        {
            question: "Czy podanie tlenu może zaszkodzić przy Barotraumie?",
            options: [
                "Tak, może rozerwać płuca",
                "Nie, tlen jest zawsze korzystny w wypadkach nurkowych",
                "Zależy od głębokości",
                "Tylko na receptę"
            ],
            correctAnswer: 1,
            explanation: "W pierwszej pomocy na powierzchni (1 ATA) tlen 100% jest bezpieczny i zawsze zalecany przy podejrzeniu jakiegokolwiek urazu ciśnieniowego."
        },
        {
            question: "Jakie jest ryzyko przy lataniu samolotem z nieleczoną odmą opłucnową (Barotrauma)?",
            options: [
                "Brak ryzyka",
                "Rozprężenie gazu w opłucnej na wysokości może doprowadzić do zapaści płuca i śmierci",
                "Tylko ból ucha",
                "Szybsze wyzdrowienie"
            ],
            correctAnswer: 1,
            explanation: "Obniżone ciśnienie w samolocie spowoduje rozprężenie powietrza w jamie opłucnej (zgodnie z prawem Boyle'a), co może być śmiertelne."
        },
        {
            question: "Czy utrata przytomności po wynurzeniu to zawsze DCS?",
            options: [
                "Tak",
                "Nie, częściej jest to objaw Zatoru Gazowego (AGE) wynikającego z Barotraumy Płuc",
                "To zawsze zmęczenie",
                "To wina sprzętu"
            ],
            correctAnswer: 1,
            explanation: "Nagła utrata przytomności tuż po wynurzeniu jest klasycznym objawem masywnego zatoru gazowego (AGE), który trafia do mózgu."
        }
    ]
};
